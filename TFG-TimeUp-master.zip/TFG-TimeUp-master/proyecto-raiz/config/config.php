<?php
// config/config.php

return [
    'db_host' => 'localhost',             // Servidor de la base de datos
    'db_user' => 'root',                  // Usuario
    'db_pass' => '',                      // Contraseña (vacía en XAMPP por defecto)
    'db_name' => 'timeup' // Nombre exacto de tu BD (ojo con la ortografía)
];
